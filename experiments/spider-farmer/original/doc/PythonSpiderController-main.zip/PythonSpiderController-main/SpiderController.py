import asyncio
import json
import paho.mqtt.client as mqtt
import logging
from SpiderBLE.BLEPairingManager import BLEPairingManager

# Logging für bessere Fehleranalyse in Node-RED
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger("SpiderController")


class SpiderController:
    def __init__(self, db_path="devices.json", mqtt_broker="localhost"):
        self.db_path = db_path
        self.mqtt_broker = mqtt_broker
        self.managers = {}  # Speichert {device_id: manager_instance}
        self.mqtt_client = mqtt.Client()
        self.loop = None

    def on_connect(self, client, userdata, flags, rc):
        logger.info(f"MQTT verbunden mit Status {rc}")
        # Abonniert Kommandos für alle Geräte: spider/control/DEVICE_ID
        client.subscribe("spider/control/+")

    def on_message(self, client, userdata, msg):
        """Verarbeitet eingehende MQTT-Befehle."""
        try:
            topic_parts = msg.topic.split('/')
            device_id = topic_parts[-1]
            command = msg.payload.decode('utf-8')

            if device_id in self.managers:
                logger.info(f"Befehl '{command}' empfangen für Gerät {device_id}")
                # Befehl in die Queue des jeweiligen Managers legen
                asyncio.run_coroutine_threadsafe(
                    self.managers[device_id].execute_command(command),
                    self.loop
                )
            else:
                logger.warning(f"Gerät {device_id} nicht in Datenbank gefunden.")
        except Exception as e:
            logger.error(f"Fehler bei MQTT-Verarbeitung: {e}")

    async def run(self):
        self.loop = asyncio.get_running_loop()

        # 1. Datenbank laden
        try:
            with open(self.db_path, "r") as f:
                config_data = json.load(f)
        except Exception as e:
            logger.error(f"Konnte {self.db_path} nicht laden: {e}")
            return

        # 2. MQTT initialisieren
        self.mqtt_client.on_connect = self.on_connect
        self.mqtt_client.on_message = self.on_message
        self.mqtt_client.connect(self.mqtt_broker, 1883, 60)
        self.mqtt_client.loop_start()

        # 3. Manager für jedes Gerät starten
        tasks = []
        for dev_cfg in config_data.get("devices", []):
            dev_id = dev_cfg.get("id")
            logger.info(f"Initialisiere Gerät: {dev_id} ({dev_cfg.get('mac')})")

            # Instanziierung des Managers mit dem kompletten Config-Dict
            manager = BLEPairingManager(dev_cfg)
            # Wir übergeben dem Manager den MQTT-Client für Status-Updates
            manager.set_mqtt_client(self.mqtt_client)

            self.managers[dev_id] = manager
            tasks.append(manager.run_flow())

        # 4. Alle Geräte-Tasks parallel ausführen
        if tasks:
            await asyncio.gather(*tasks)
        else:
            logger.warning("Keine Geräte zum Starten gefunden.")


if __name__ == "__main__":
    controller = SpiderController()
    try:
        asyncio.run(controller.run())
    except KeyboardInterrupt:
        logger.info("Controller manuell gestoppt.")