import asyncio
import json
import paho.mqtt.client as mqtt
from SpiderBLE.BLEPairingManager import BLEPairingManager

# MQTT Einstellungen
MQTT_BROKER = "localhost"
MQTT_CMD_TOPIC = "spider/+/cmd"  # + ist Platzhalter für die Device-ID


class MQTTBridge:
    def __init__(self):
        self.managers = {}  # Hält die Instanzen pro MAC/ID
        self.client = mqtt.Client()

    def on_connect(self, client, userdata, flags, rc):
        print(f"MQTT verbunden mit Status {rc}")
        client.subscribe(MQTT_CMD_TOPIC)

    def on_message(self, client, userdata, msg):
        try:
            # Topic-Struktur: spider/spider_01/cmd
            parts = msg.topic.split('/')
            device_id = parts[1]
            command = msg.payload.decode()  # z.B. "device_status"

            if device_id in self.managers:
                print(f"[MQTT] Befehl '{command}' an {device_id}...")
                asyncio.run_coroutine_threadsafe(
                    self.managers[device_id].execute_command(command),
                    self.loop
                )
        except Exception as e:
            print(f"Fehler bei MQTT Nachricht: {e}")

    async def run(self):
        self.loop = asyncio.get_running_loop()

        # 1. Geräte aus DB laden
        with open("devices.json", "r") as f:
            db = json.load(f)

        # 2. Für jedes Gerät einen Manager starten
        tasks = []
        for dev in db["devices"]:
            mgr = BLEPairingManager(mac=dev["mac"])  # Manager braucht jetzt mac als Parameter
            self.managers[dev["id"]] = mgr
            tasks.append(mgr.run_flow())

        # 3. MQTT starten
        self.client.on_connect = self.on_connect
        self.client.on_message = self.on_message
        self.client.connect(MQTT_BROKER, 1883, 60)
        self.client.loop_start()

        # Alle Geräte-Tasks gleichzeitig ausführen
        await asyncio.gather(*tasks)


if __name__ == "__main__":
    bridge = MQTTBridge()
    asyncio.run(bridge.run())