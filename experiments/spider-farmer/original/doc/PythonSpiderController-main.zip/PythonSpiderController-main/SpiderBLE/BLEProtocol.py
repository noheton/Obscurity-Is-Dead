import struct
from Crypto.Cipher import AES

from .BLEConfig import BLEConfig


class BLEProtocol:
    def __init__(self, config_dict):
        self.cfg = config_dict

    def calculate_crc16(self, data: bytes) -> int:
        crc = 0xFFFF
        for byte in data:
            crc ^= byte
            for _ in range(8):
                if crc & 0x0001:
                    crc = (crc >> 1) ^ 0xA001
                else:
                    crc >>= 1
        return crc & 0xFFFF

    def encrypt_and_wrap(self, json_str: str) -> bytes:
        data = json_str.encode('utf-8')
        pad_len = 16 - (len(data) % 16)
        if pad_len != 16: data += b'\x00' * pad_len

        cipher = AES.new(self.cfg['key'].encode(), AES.MODE_CBC, self.cfg['iv'].encode())
        encrypted = cipher.encrypt(data)

        # Meta-Block (14 Bytes)
        meta = struct.pack('>HHIIH', 2, self.calculate_crc16(encrypted), len(encrypted), 0, len(encrypted))

        packet = bytearray([0xAA, 0xAA, 0x00, 0x03])
        packet.extend(struct.pack('>H', len(meta) + len(encrypted)))
        packet.extend(meta)
        packet.extend(encrypted)
        packet.extend(struct.pack('>H', self.calculate_crc16(packet)))
        return bytes(packet)

    def decrypt_and_unwrap(self, ciphertext: bytes, iv: bytes) -> str:
        try:
            # AES-CBC benötigt ein Vielfaches von 16
            data_to_decrypt = bytearray(ciphertext)
            if len(data_to_decrypt) % 16 != 0:
                padding_needed = 16 - (len(data_to_decrypt) % 16)
                data_to_decrypt += b'\x00' * padding_needed

            cipher = AES.new(self.cfg['key'].encode(), AES.MODE_CBC, iv)
            decrypted = cipher.decrypt(data_to_decrypt)

            # Dekodieren und säubern
            raw_text = decrypted.decode('utf-8', errors='ignore').strip('\x00')

            # JSON-Grenzen suchen (wie im C++ indexOf('{'))
            start = raw_text.find('{')
            end = raw_text.rfind('}')
            if start != -1 and end != -1:
                return raw_text[start:end + 1]
            return ""
        except Exception as e:
            return ""