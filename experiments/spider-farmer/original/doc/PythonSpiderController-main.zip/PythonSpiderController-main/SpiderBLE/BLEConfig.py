# --- 1. KONFIGURATION ---
class BLEConfig:
    MAC_ADDRESS = "90:e5:b1:b7:b1:ae"
    WRITE_UUID = "0000ff02-0000-1000-8000-00805f9b34fb"
    NOTIFY_UUID = "0000ff01-0000-1000-8000-00805f9b34fb"

    KEY = b"BkJu61kLt3afuogT"
    IV = b"2AKVNUbU4mvU3Elt"  # Static-IV for outgoing request

    USER_ID = "1000000"
    USER_EMAIL = "example@example.com"
    PRODUCT_ID = "90E5B1B7B1AC"
    TIMEZONE = "Europe/Berlin"
    TZ = "CET-1CEST,M3.5.0,M10.5.0/3"
    GMTOFF = 3600


    def user_id(self):
        return self.USER_ID


    def timezone(self):
        return self.TIMEZONE

    def tz(self):
        return self.TZ

    def gmtoff(self):
        return self.GMTOFF


    def user_email(self):
        return self.USER_EMAIL

    def mac_address(self):
        return self.MAC_ADDRESS

    def write_uuid(self):
        return self.WRITE_UUID

    def notification_uuid(self):
        return self.NOTIFY_UUID

    def key(self):
        return self.KEY

    def iv(self):
        return self.IV