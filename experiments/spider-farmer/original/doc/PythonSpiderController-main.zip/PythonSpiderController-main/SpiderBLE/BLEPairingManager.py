import asyncio
import json
import struct
from bleak import BleakClient
from .BLEProtocol import BLEProtocol
from .BLEConfig import BLEConfig
from .BLEPayloads import BLEPayloads


class BLEPairingManager:
    def __init__(self, device_config):
        self.protocol = BLEProtocol(self.cfg)  # Reicht Daten weiter
        self.payloads = BLEPayloads(self.cfg)  # Reicht Daten weiter
        self.cfg = device_config  # Hier liegen jetzt alle Werte (key, iv, pcode...)
        self.protocol = BLEProtocol(self.cfg['key'], self.cfg['iv'])
        self.payloads = BLEPayloads(self.cfg)
        self.mac = self.cfg['mac']
        self.write_uuid = self.cfg['write_uuid']
        self.notify_uuid = self.cfg['notify_uuid']
        self.command_queue = asyncio.Queue()
        self.protocol = BLEProtocol()
        self.config = BLEConfig()
        self.payloads = BLEPayloads()
        self.client = None
        self.max_retries = retries
        self.data_buffer = bytearray()
        self.json_accumulator = ""
        self.current_command = None
        self.last_sent_id = None
        self.bytes_received_session = 0

    def set_mqtt_client(self, client):
        self.mqtt_client = client

    async def notification_handler(self, sender, data):
        self.data_buffer.extend(data)
        self.bytes_received_session += len(data)

    async def send_with_retry(self, method, payload_provider):
        self.current_command = method
        # Längerer Timeout für Systemstatus, da das Gerät hier oft länger braucht
        wait_time = 35.0 if method == "getSysSta" else 15.0

        for attempt in range(1, self.max_retries + 1):
            self.data_buffer.clear()
            self.bytes_received_session = 0

            # Payload über den dynamischen Provider beziehen
            raw_payload = payload_provider() if callable(payload_provider) else payload_provider
            payload_json = json.loads(raw_payload)
            self.last_sent_id = str(payload_json["msgId"])

            # Verschlüsselung mit dem Key aus der Geräte-Config
            encrypted_packet = self.protocol.encrypt_and_wrap(raw_payload)

            print(f"\n>>> SEND [Device: {self.cfg['id']}]: {method} (Versuch {attempt})")
            await asyncio.sleep(0.3)  # Stabilisierung für Windows BLE Stack

            # Senden über die UUID aus der Config
            await self.client.write_gatt_char(self.cfg['write_uuid'], encrypted_packet, response=True)

            start_time = asyncio.get_running_loop().time()
            while (asyncio.get_running_loop().time() - start_time) < wait_time:
                if len(self.data_buffer) >= 8:
                    # 1. Header-Synchronisation (Suche Magic Bytes 0xAAAA)
                    pos = self.data_buffer.find(b'\xAA\xAA')
                    if pos != -1:
                        self.data_buffer = self.data_buffer[pos:]
                    else:
                        self.data_buffer.clear()
                        continue

                    if len(self.data_buffer) >= 6:
                        payload_len = struct.unpack(">H", self.data_buffer[4:6])[0]
                        total_size = payload_len + 8

                        if len(self.data_buffer) >= total_size:
                            packet = bytes(self.data_buffer[:total_size])
                            self.data_buffer = self.data_buffer[total_size:]

                            header_offset = 20  # 6 Outer + 14 Inner Header
                            encrypted_part = packet[header_offset:-2]

                            # --- SCHRITT A: Versuch mit statischem IV (aus devices.json) ---
                            decrypted = self.protocol.decrypt_and_unwrap(
                                encrypted_part,
                                self.cfg['iv'].encode()  # Konvertierung String -> Bytes
                            )

                            # --- SCHRITT B: Fallback auf dynamischen IV (für Events/Status) ---
                            if "{" not in decrypted:
                                dynamic_iv = bytearray(packet[6:20])
                                dynamic_iv.extend(b'\x00\x00')  # Auf 16 Bytes auffüllen

                                decrypted = self.protocol.decrypt_and_unwrap(
                                    encrypted_part,
                                    bytes(dynamic_iv)
                                )

                            # --- SCHRITT C: JSON & MQTT Auswertung ---
                            if decrypted and "{" in decrypted:
                                try:
                                    # Jede gültige Nachricht geht sofort an Node-RED
                                    topic = f"spider/status/{self.cfg['id']}"
                                    self.mqtt_client.publish(topic, decrypted)

                                    resp = json.loads(decrypted)
                                    resp_id = str(resp.get("msgId", ""))

                                    # Prüfen, ob das die Antwort auf unseren aktuellen Befehl ist
                                    if resp_id == self.last_sent_id:
                                        print(f"[OK] Antwort erhalten & an MQTT gesendet.")
                                        return resp
                                    else:
                                        print(f"<- Hintergrund-Event an MQTT: {topic}")

                                except json.JSONDecodeError:
                                    continue

                await asyncio.sleep(0.01)  # CPU-Schonung

            print(f"[!] Timeout {method} für {self.cfg['id']}. Empfangen: {self.bytes_received_session} Bytes.")
        return None

    async def start_heartbeat(self):
        """Sendet alle 30 Sekunden einen Status-Request, um die Verbindung zu halten."""
        print("[HEARTBEAT] Aktiviert.")
        try:
            while self.client and self.client.is_connected:
                await asyncio.sleep(30)
                print(f"\n[HEARTBEAT] Sende Status-Check...")
                # Wir nutzen get_device_status (oder get_system_status) als Heartbeat
                await self.send_with_retry("heartbeat", self.payloads.get_device_status)
        except asyncio.CancelledError:
            print("[HEARTBEAT] Gestoppt.")
        except Exception as e:
            print(f"[HEARTBEAT] Fehler: {e}")

    async def run_flow(self):
        print(f"Verbinde mit {self.config.MAC_ADDRESS}...")
        async with BleakClient(self.config.MAC_ADDRESS) as client:
            self.client = client
            print(f"[BLE] MTU: {client.mtu_size}")
            await client.start_notify(self.config.NOTIFY_UUID, self.notification_handler)

            # Heartbeat Task erstellen
            heartbeat_task = asyncio.create_task(self.start_heartbeat())

            try:
                # Ablauf der Schritte (INNERHALB des Context Managers)
                steps = [
                    ("1", "getDevSta", self.payloads.get_device_status),
                    ("2", "setDevTimezone", self.payloads.get_timezone_payload),
                    ("3", "setDevActive", self.payloads.get_activation_payload)
                ]

                for step, method, payload in steps:
                    print(f"\n[SCHRITT {step}] {method}...")
                    if not await self.send_with_retry(method, payload):
                        print(f"[ABORT] Fehler in Schritt {step}")
                        return  # Beendet den Flow bei Fehler

                    await asyncio.sleep(1.5)

                print("\n[INFO] Handshake abgeschlossen. Bleibe verbunden...")

                # Endlosschleife um die Verbindung offen zu halten (wie C++ loop)
                while client.is_connected:
                    await asyncio.sleep(1)

            except Exception as e:
                print(f"[ERROR] Im Flow: {e}")
            finally:
                # Sauber aufräumen
                heartbeat_task.cancel()
                try:
                    await heartbeat_task
                except asyncio.CancelledError:
                    pass
                await client.stop_notify(self.config.NOTIFY_UUID)
                print("Verbindung sauber getrennt.")