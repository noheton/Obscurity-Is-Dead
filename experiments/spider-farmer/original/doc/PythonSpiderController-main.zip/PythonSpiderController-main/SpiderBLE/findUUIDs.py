import asyncio
from bleak import BleakClient

# Scan the BLE GATT Services from Spider Farmer SE-1500
# find the UUIDS from esp32s3
async def scan_services(address):
    async with BleakClient(address) as client:
        print(f"Services von {address}:")
        for service in client.services:
            print(f"\nService: {service.uuid}")
            for char in service.characteristics:
                print(f"  └─ Charakteristik: {char.uuid} | Properties: {char.properties}")

# Use your BLE MAC-Address here
asyncio.run(scan_services("90:e5:b1:b7:b1:ae"))