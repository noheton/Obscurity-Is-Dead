import calendar
import json
import time
from datetime import datetime


class BLEPayloads:
    def __init__(self, device_config: dict):
        """
        device_config enthält alle Daten aus der devices.json für dieses spezifische Gerät:
        id, pcode, mac, key, iv, pid, etc.
        """
        self.config = device_config

    def create_base(self, method: str, params: dict = None):
        """Erstellt das Standard-JSON-Gerüst."""
        return json.dumps({
            "method": method,
            "params": params or {},
            "msgId": str(round(time.time() * 1000)),
            # Nutzt die UID/ID aus der Konfiguration
            "uid": self.config.get("id", "1000000")
        })

    # --- DYNAMISCHER DISPATCHER ---
    def get_payload_by_name(self, cmd_name: str):
        """
        Sucht zuerst nach einer PCODE-spezifischen Methode,
        dann nach einer Standard-Methode.
        Beispiel: cmd_name='device_status' & pcode='SPIDER_V1'
        -> sucht 'get_SPIDER_V1_device_status'
        """
        pcode = self.config.get("pcode", "GENERIC")
        specific_method_name = f"get_{pcode}_{cmd_name}"
        standard_method_name = f"get_{cmd_name}"

        # 1. Spezifisch für PCODE?
        if hasattr(self, specific_method_name):
            return getattr(self, specific_method_name)()
        # 2. Standard?
        elif hasattr(self, standard_method_name):
            return getattr(self, standard_method_name)()
        else:
            print(f"[ERROR] Kein Payload für '{cmd_name}' (PCODE: {pcode}) gefunden.")
            return None

    # --- STANDARD PAYLOADS (Für die meisten Geräte gleich) ---

    def get_timezone_payload(self):
        # Nutzt Default-Werte falls nicht in devices.json definiert
        return self.create_base("setDevTimezone", {
            "timezone": self.config.get("timezone", "Europe/Berlin"),
            "TZ": self.config.get("tz", "CET-1CEST,M3.5.0,M10.5.0/3"),
            "UTC": calendar.timegm(datetime.now().utctimetuple()),
            "gmtoff": self.config.get("gmtoff", 3600)
        })

    def get_activation_payload(self):
        return self.create_base("setDevActive", {
            "uid": self.config.get("id"),
            "uname": self.config.get("user_email", "example@example.com")
        })

    def get_device_status(self):
        return self.create_base("getDevSta")

    def get_system_status(self):
        return self.create_base("getSysSta")

    def get_device_restart(self):
        return self.create_base("setDevRestart")

    # --- SPEZIFISCHE PAYLOADS (Beispiel für unterschiedliche Hardware) ---

    def get_SPIDER_V1_device_status(self):
        """Beispiel: V1 braucht vielleicht ein extra Parameter im Status."""
        return self.create_base("getDevSta", {"verbose": True})

    def get_SPIDER_V2_wifi_setup(self):
        """Beispiel: V2 hat ein anderes WiFi-Setup-Kommando."""
        return self.create_base("setWifiV2", {
            "ssid": self.config.get("wifi_ssid"),
            "key": self.config.get("wifi_pass")
        })

    # Konfiguration & Zeit
    def get_timezone_payload(self):
        return self.create_base("setDevTimezone", {"timezone": self.config.timezone(),"TZ": self.config.tz(),"UTC": calendar.timegm(datetime.now().utctimetuple()),"gmtoff": self.config.gmtoff()})

    def get_wifi_payload(self):
        return self.create_base("setWifi", {"uid": self.config.user_id(), "uname": self.config.user_email()})

    def get_time_sync_payload(self):
        return self.create_base("setTimeSync", {"uid": self.config.user_id(), "uname": self.config.user_email()})

    # System-Zustand & Aktivierung
    def get_activation_payload(self):
        return self.create_base("setDevActive", {"uid": self.config.user_id(), "uname": self.config.user_email()})

    def get_deactivation_payload(self):
        return self.create_base("setDevDeactive", {"uid": self.config.user_id(), "uname": self.config.user_email()})

    # Status-Abfragen
    def get_system_status(self):
        return self.create_base("getSysSta")

    def get_device_status(self):
        return self.create_base("getDevSta")

    # OTA & Firmware
    def get_system_upgrade(self):
        return self.create_base("runUpgrade")

    def get_ota_info(self):
        return self.create_base("getOtaInfo")

    def get_ota_ver(self):
        return self.create_base("getOtaVer")

    # Wartung & Neustart
    def get_device_restart(self):
        return self.create_base("setDevRestart")

    def get_device_reset(self):
        return self.create_base("setDevReset")

    def get_device_restore(self):
        return self.create_base("setDevRestore")

    # Dateisystem & Parameter