# Control your Spider Farmer with Python

With this tool, a PC and a Bluetooth stick, it is possible to use the Spider Farmer lamps.
I think it's a good creative basis for deriving your own smart home control system from it.

##### ⚠️⚠️ Please do not share this information publicly. ⚠️⚠️

### Header Structure

![byteheader_payload.png](byteheader_payload.png)

## What can do


#### ⚠️⚠️ Important: The hardware key must be concealed. Publishing it is illegal. ⚠️⚠️

#### Start IV in RAM and hardcoded AES
```
KEY = b"BkJu61kLt3afuogT"
IV = b"2AKVNUbU4mvU3Elt"
```

## Install

```
bash
pip install -r requirements.txt
```

## Run

```
bash
python SpiderController.py
```

### BLE protobuf


#### Available function called over MQTT or BLE
| Method         | Parameter  | Description                                     |   |
|----------------|------------|-------------------------------------------------|---|
| setDevTimezone | JSON ARRAY | Time sincronitaion between APP & DEVICE         |   |
| setDevActive   |            | Bounding device                                 |   |
| setDevDeactive |            | Unbounding device                               |   |
| getDevSta      |            | Get device information dimming and light        |   |
| getSysSta      |            | Get hardware and antenna connection information |   |
| getConfigFile  |            | Get time shuduele plan settings                 |   |
| setMode        |            | Set the mode alternative to knop press          |   |
| setOnOff       |            | Device power on, off                            |   |
| setConfigFile  |            | --unknow-- logical must                         |   |


# TODO 
- [ ] add dynamic methods
- [ ] week plan upload
- [ ] add payloads