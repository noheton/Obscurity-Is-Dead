import paho.mqtt.client as mqtt
import time

# --- KONFIGURATION ---
BROKER_IP = "192.168.178.XX"  # IP deines MQTT Brokers
CMND_TOPIC = "spider_farmer/cmnd"
STATUS_TOPIC = "spider_farmer/status"


# Callback: Wenn eine Nachricht von der Bridge (ESP32) kommt
def on_message(client, userdata, msg):
    print(f"\n[ANTWORT VON BRIDGE] Topic: {msg.topic}")
    try:
        # Versuche das empfangene JSON schön darzustellen
        import json
        data = json.loads(msg.payload.decode())
        print(json.dumps(data, indent=4))
    except:
        print(msg.payload.decode())


# MQTT Setup
client = mqtt.Client()
client.on_message = on_message

print(f"Verbinde mit Broker: {BROKER_IP}...")
client.connect(BROKER_IP, 1883, 60)

# Auf Status-Kanal lauschen
client.subscribe(STATUS_TOPIC)
client.loop_start()

try:
    while True:
        print("\n--- Spider Farmer Steuerung ---")
        print("1: System-Status abfragen (getSysSta)")
        print("2: Timezone setzen (setDevTimezone)")
        print("3: Aktivieren (setDevActive)")
        print("q: Beenden")

        wahl = input("Wähle eine Option: ")

        if wahl == "1":
            client.publish(CMND_TOPIC, "getSysSta")
            print(">>> Befehl 'getSysSta' gesendet...")
        elif wahl == "2":
            client.publish(CMND_TOPIC, "setDevTimezone")
            print(">>> Befehl 'setDevTimezone' gesendet...")
        elif wahl == "3":
            client.publish(CMND_TOPIC, "setDevActive")
            print(">>> Befehl 'setDevActive' gesendet...")
        elif wahl == "q":
            break

        time.sleep(2)  # Kurz warten auf die Antwort

except KeyboardInterrupt:
    pass

client.loop_stop()
client.disconnect()