# Spider BLE Bridge

Die Spider Farmer Bluetooth Bridge soll dazu dienen, um Spider Farmer Lampen
direkt in Smarthome Anwendung zu einzubinden.

Über Bluetooth ist die Antwort vom Lampen-Kontroller so schnell grade einmal 10ms
das es ohne BLE Dongle kaum möglich ist damit zu Arbeiten.

Vermutlich ist aber auch eine direkte Verbindung mit MQTT zu dem
Lampen-Kontroller möglich, wenn dieser in Soft-AP modus ist. Danach muss ich noch
weiter Forschen.

Was auch noch unbekannt ist welche daten zu dem Cloudservice übermittelt werden
darum würde ich zur verwendung der Lampe nur im Intranet raten.

# ⚠️ Der IV und KEY dürfen nicht veröffentlicht werden ⚠️⚠️

# ⚠️⚠️ Auch keine Code fragmente aus dieser Software. ⚠️






# Developer information

# Attention
The SE-1500 use Statik IV for request and dynamic IV for regular event massages



This build the project files to the build folder on error show debug information
```bash
pio run
```

Run build and flashing the device with new firmware.elf from build folder
```bash
pio run --target upload --upload-port COM9
```

Show connected devices on PC usb port
```bash
pio device list
```

Listen to monitor port
```bash
pio device monitor
```

# After install
If the second ESP device flashed and connected to the Windows PC
we can use at as dummy Bluetooth antenna bridge run the python script
to read from serial:

`python SerialBridge.py`

Use a Putty Terminal the python script is tow slow
buffer overflow destroy valid data!

SpiderBridge/

├── .pio/                    # (Wird von PlatformIO automatisch erstellt)

├── include/                 # (Hier können .h Dateien rein, falls du das Projekt aufteilst)

├── lib/                     # (Für eigene, lokale Bibliotheken)

├── src/
│   └── main.cpp             # Dein Hauptcode (C++ Code von oben)

├── test/                    # (Für Unit-Tests, falls benötigt)

├── .gitignore               # (Standard Git-Ausschlussliste)

├── CMakeLists.txt           # (Wird von PlatformIO/CLion verwaltet)

└── platformio.ini           # Die wichtigste Konfigurationsdatei


# TODO
- [x] ~~add partition table~~

# Trouble

CMAKE problem new init ide file
```
bash
pio init --ide clion
```