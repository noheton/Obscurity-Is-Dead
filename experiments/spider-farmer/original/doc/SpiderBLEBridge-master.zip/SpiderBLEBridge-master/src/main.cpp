#include <Arduino.h>
#include <WiFi.h>
#include <vector>
#include <ArduinoJson.h>
#include "BLEDevice.h"
#include "BLEProtocol.h"
#include "BLEPayloads.h"
#include "arduino_secrets.h"

// Globale Instanzen & Variablen
BLEProtocol protocol;
BLEPayloads payloads;
BLERemoteCharacteristic* pWriteChar = nullptr;

std::vector<uint8_t> rxBuffer;
String lastSentId = "";
String lastDecryptedResponse = "";
bool responseReceived = false;
bool connected = false;
bool doConnect = false;
bool doScan = true;
size_t expectedLen = 0; // Hier hinzufüge

// NEU: Status-Variablen
bool isBounded = false;
unsigned long sessionStart = 0;
unsigned long lastHeartbeat = 0;
const unsigned long HEARTBEAT_INTERVAL = 30000;

// UUIDs (wie gehabt)
static BLEUUID serviceUUID("000000ff-0000-1000-8000-00805f9b34fb");
static BLEUUID  notifyUUID("0000ff01-0000-1000-8000-00805f9b34fb");
static BLEUUID   writeUUID("0000ff02-0000-1000-8000-00805f9b34fb");
BLEAdvertisedDevice* myDevice = nullptr;

// --- KORRIGIERTE CALLBACK LOGIK ---
static void notifyCallback(BLERemoteCharacteristic* pChar, uint8_t* pData, size_t len, bool isNotify) {
    // 1. Daten in den Puffer schieben
    for (size_t i = 0; i < len; i++) rxBuffer.push_back(pData[i]);

    // 2. Header suchen (0xAAAA)
    while (rxBuffer.size() >= 8) {
        if (rxBuffer[0] == 0xAA && rxBuffer[1] == 0xAA) break;
        rxBuffer.erase(rxBuffer.begin());
    }

    // 3. Paketlänge prüfen
    if (rxBuffer.size() >= 6) {
        expectedLen = (rxBuffer[4] << 8 | rxBuffer[5]) + 8;
    }

    // 4. Verarbeitung bei vollständigem Paket
    if (expectedLen > 0 && rxBuffer.size() >= expectedLen) {
        int headerOffset = 20; // 6 Outer + 14 Inner
        int encryptedPartLen = expectedLen - headerOffset - 2; // -2 für CRC

        if (encryptedPartLen > 0) {
            // --- SCHRITT A: Versuch mit statischem IV (für Antworten auf Befehle) ---
            uint8_t static_iv[16] = SECRET_AES_IV;
            String decrypted = protocol.decrypt_and_unwrap(rxBuffer.data() + headerOffset, encryptedPartLen, static_iv);

            // Wenn das Ergebnis kein gültiges JSON ist, Versuch mit dynamischem IV (für Events)
            if (decrypted.indexOf('{') == -1) {
                uint8_t dynamic_iv[16];
                // Wir nehmen die 14 Bytes des Inner Headers ab Index 6 und füllen auf 16 auf
                memcpy(dynamic_iv, rxBuffer.data() + 6, 14);
                dynamic_iv[14] = 0x00; dynamic_iv[15] = 0x00;

                decrypted = protocol.decrypt_and_unwrap(rxBuffer.data() + headerOffset, encryptedPartLen, dynamic_iv);
            }

            // 5. JSON Parsen und Auswerten
            if (decrypted.length() > 0 && decrypted.indexOf('{') != -1) {
                DynamicJsonDocument respDoc(2048);
                DeserializationError err = deserializeJson(respDoc, decrypted);

                if (!err) {
                    String respId = respDoc["msgId"] | "";

                    // ID Check für den Flow
                    if (respId != "" && respId == lastSentId) {
                        Serial.printf("\033[32m[OK] Antwort empfangen: %s\033[0m\n", decrypted.c_str());
                        lastDecryptedResponse = decrypted;
                        responseReceived = true;
                    } else {
                        // Es ist ein unaufgeforderter Status-Report
                        Serial.printf("\033[33m<- Status/Event: %s\033[0m\n", decrypted.c_str());
                    }
                }
            }
        }

        // Puffer bereinigen
        rxBuffer.erase(rxBuffer.begin(), rxBuffer.begin() + expectedLen);
        expectedLen = 0;
    }
}

// --- SEND LOGIK ---
bool sendWithRetry(String json, int maxRetries = 3) {
    if (!pWriteChar) return false;
    DynamicJsonDocument tempDoc(256);
    deserializeJson(tempDoc, json);
    lastSentId = tempDoc["msgId"] | "";

    for (int attempt = 1; attempt <= maxRetries; attempt++) {
        rxBuffer.clear();
        responseReceived = false;
        Serial.printf("\033[34m>>> [TRY %d] Send ID %s...\033[0m\n", attempt, lastSentId.c_str());

        auto packet = protocol.encrypt_and_wrap(json);
        pWriteChar->writeValue(packet.data(), packet.size(), true);

        unsigned long start = millis();
        while (millis() - start < 5000) {
            if (responseReceived) return true;
            delay(10);
        }
    }
    return false;
}

void runActivationFlow() {
    Serial.println("\n[FLOW] Starte gesicherten Handshake...");

    // 1. Schritt: Systemstatus abrufen (Bestätigt Kommunikation)
    // Nutzt: {"method":"getSysSta","params":{},"msgId":"...","uid":"1000000"}
    if (sendWithRetry(payloads.get_system_status())) {

        // 2. Schritt: Zeit setzen (Wichtig für interne Logs des Geräts)
        // Nutzt: {"method":"setTmze","params":{"utc":...},"msgId":"...","uid":"1000000"}
        if (sendWithRetry(payloads.get_timezone_payload(time(NULL)))) {

            // 3. Schritt: Bounding/Aktivierung
            // Nutzt: {"method":"bindGer","params":{"uid":"1000000","token":"0"},"msgId":"...","uid":"1000000"}
            if (sendWithRetry(payloads.get_activation_payload())) {
                isBounded = true;
                sessionStart = millis();
                Serial.println("[SUCCESS] Gerät vollständig aktiviert!" );
            }
        }
    }
}

// --- BLE CALLBACKS ---
class MyClientCallback : public BLEClientCallbacks {
    void onConnect(BLEClient* p) { connected = true; }
    void onDisconnect(BLEClient* p) { connected = false; doScan = true; Serial.println("Disconnected."); }
};

class MyAdvertisedDeviceCallbacks : public BLEAdvertisedDeviceCallbacks {
    void onResult(BLEAdvertisedDevice adv) {
        if (adv.getAddress().toString() == SECRET_MAC_ADDRESS) {
            BLEDevice::getScan()->stop();
            if (myDevice) delete myDevice;
            myDevice = new BLEAdvertisedDevice(adv);
            doConnect = true; doScan = false;
        }
    }
};

void setup() {
    Serial.begin(115200);
    WiFi.begin(SECRET_SSID, SECRET_PASS);
    while (WiFi.status() != WL_CONNECTED) delay(500);
    configTime(3600, 3600, "pool.ntp.org");
    BLEDevice::init("ESP32-Bridge");
    BLEScan* pScan = BLEDevice::getScan();
    pScan->setAdvertisedDeviceCallbacks(new MyAdvertisedDeviceCallbacks());
    pScan->start(0, false);
}

void loop() {
    if (doConnect) {
        BLEClient* pClient = BLEDevice::createClient();
        pClient->setClientCallbacks(new MyClientCallback());
        if (pClient->connect(myDevice)) {
            pClient->setMTU(500);
            delay(500);
            BLERemoteService* pSvc = pClient->getService(serviceUUID);
            if (pSvc) {
                pWriteChar = pSvc->getCharacteristic(writeUUID);
                auto pNoti = pSvc->getCharacteristic(notifyUUID);
                if (pWriteChar && pNoti) {
                    pNoti->registerForNotify(notifyCallback);

                    // Nur aktivieren, wenn noch nicht geschehen
                    if (!isBounded) {
                        runActivationFlow();
                    } else {
                        sessionStart = millis(); // Uptime Reset nach Reconnect
                        Serial.println("\033[32m[INFO] Reconnect: Bounding bereits aktiv.\033[0m");
                    }
                }
            }
        }
        doConnect = false;
    }

    // Heartbeat & Uptime
    if (connected && isBounded && pWriteChar) {
        if (millis() - lastHeartbeat > HEARTBEAT_INTERVAL) {
            unsigned long up = (millis() - sessionStart) / 1000;
            Serial.printf("\033[34m[HEARTBEAT] Uptime: %lu s | Bounded: JA\033[0m\n", up);
            if (sendWithRetry(payloads.get_system_status(), 1)) {
                lastHeartbeat = millis();
            }
        }
    }

    if (!connected && doScan) {
        static uint32_t lt = 0;
        if (millis() - lt > 5000) { BLEDevice::getScan()->start(5, false); lt = millis(); }
    }
    delay(10);
}