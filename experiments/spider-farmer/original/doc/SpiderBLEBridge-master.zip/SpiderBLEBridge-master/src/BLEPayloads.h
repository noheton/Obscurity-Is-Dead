#ifndef BLE_PAYLOADS_H
#define BLE_PAYLOADS_H

#include <ArduinoJson.h>
#include "arduino_secrets.h"

class BLEPayloads {
private:
    static String create_base(const char* method, JsonVariant params) {
        DynamicJsonDocument doc(1024);
        doc["method"] = method;
        doc["params"] = params;

        // Erzeugt einen 13-stelligen Timestamp (Sekunden * 1000 + Millis-Rest)
        // Das entspricht exakt der Python-Logik
        const unsigned long long ms = static_cast<unsigned long long>(time(nullptr)) * 1000 + (millis() % 1000);
        doc["msgId"] = String(ms);

        doc["uid"] = SECRET_USER_ID;

        String out;
        serializeJson(doc, out);
        return out;
    }

public:
    BLEPayloads() = default;

    static String get_system_status() {
        DynamicJsonDocument doc(256);
        JsonObject params = doc.to<JsonObject>();
        return create_base("getSysSta", params);
    }

    static String get_timezone_payload(unsigned long epoch) {
        DynamicJsonDocument doc(512);
        JsonObject params = doc.to<JsonObject>();
        params["timezone"] = SECRET_TIMEZONE;
        params["TZ"] = SECRET_TZ_STRING;
        params["UTC"] = epoch;
        params["gmtoff"] = 3600;
        return create_base("setDevTimezone", params);
    }

    static String get_activation_payload() {
        DynamicJsonDocument doc(512);
        JsonObject params = doc.to<JsonObject>();
        params["uid"] = SECRET_USER_ID;
        params["uname"] = SECRET_USER_EMAIL;
        return create_base("setDevActive", params);
    }
};
#endif