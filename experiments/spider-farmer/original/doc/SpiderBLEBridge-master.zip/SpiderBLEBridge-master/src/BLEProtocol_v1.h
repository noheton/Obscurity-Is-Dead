#ifndef BLE_PROTOCOL_H
#define BLE_PROTOCOL_H

#include <Arduino.h>
#include <mbedtls/aes.h>
#include <vector>
#include "arduino_secrets.h"

class BLEProtocol {
private:
private:
    uint8_t key[16] = SECRET_AES_KEY;
    uint8_t iv[16]  = SECRET_AES_IV;

    void apply_swap(uint8_t* data, size_t len) {
        for (size_t i = 0; i < len - 1; i += 2) {
            uint8_t temp = data[i];
            data[i] = data[i+1];
            data[i+1] = temp;
        }
    }

    uint16_t calculate_crc16(const uint8_t* data, size_t len) {
        uint16_t crc = 0xFFFF;
        for (size_t i = 0; i < len; i++) {
            crc ^= data[i];
            for (int j = 0; j < 8; j++) {
                if (crc & 0x0001) crc = (crc >> 1) ^ 0xA001;
                else crc >>= 1;
            }
        }
        return crc;
    }

public:
    BLEProtocol() {}

    std::vector<uint8_t> encrypt_and_wrap(String json_str) {
        size_t data_len = json_str.length();
        // PKCS#7: Padding ist IMMER zwischen 1 und 16
        size_t pad_len = 16 - (data_len % 16);
        size_t enc_len = data_len + pad_len;

        uint8_t input[enc_len];
        memcpy(input, json_str.c_str(), data_len);
        // Padding-Bytes mit dem Wert der pad_len füllen
        for (size_t i = data_len; i < enc_len; i++) {
            input[i] = (uint8_t)pad_len;
        }

        uint8_t encrypted[enc_len];
        uint8_t working_iv[16];
        memcpy(working_iv, iv, 16);

        mbedtls_aes_context aes;
        mbedtls_aes_init(&aes);
        mbedtls_aes_setkey_enc(&aes, key, 128);
        mbedtls_aes_crypt_cbc(&aes, MBEDTLS_AES_ENCRYPT, enc_len, working_iv, input, encrypted);
        mbedtls_aes_free(&aes);

        std::vector<uint8_t> packet = {0xAA, 0xAA, 0x00, 0x03};
        uint16_t meta_plus_enc = 14 + enc_len;
        packet.push_back(meta_plus_enc >> 8);
        packet.push_back(meta_plus_enc & 0xFF);

        uint16_t enc_crc = calculate_crc16(encrypted, enc_len);
        packet.push_back(0x00); packet.push_back(0x02); // Typ 2
        packet.push_back(enc_crc >> 8); packet.push_back(enc_crc & 0xFF);
        packet.push_back(0x00); packet.push_back(0x00);
        packet.push_back(enc_len >> 8); packet.push_back(enc_len & 0xFF); // Len
        packet.push_back(0x00); packet.push_back(0x00);
        packet.push_back(0x00); packet.push_back(0x00); // Padding
        packet.push_back(enc_len >> 8); packet.push_back(enc_len & 0xFF); // Len H

        for(size_t i = 0; i < enc_len; i++) packet.push_back(encrypted[i]);

        uint16_t final_crc = calculate_crc16(packet.data(), packet.size());
        packet.push_back(final_crc >> 8); packet.push_back(final_crc & 0xFF);

        return packet;
    }

    String decrypt_and_unwrap(uint8_t* ciphertext, size_t len, uint8_t* dynamic_iv) {
        if (len % 16 != 0 || len == 0) return ""; // AES Blocksize Check

        uint8_t plaintext[len];
        uint8_t iv_copy[16]; // CBC verändert den IV beim Dekodieren, daher Kopie
        memcpy(iv_copy, dynamic_iv, 16);

        mbedtls_aes_context aes;
        mbedtls_aes_init(&aes);
        mbedtls_aes_setkey_dec(&aes, key, 128);
        mbedtls_aes_crypt_cbc(&aes, MBEDTLS_AES_DECRYPT, len, iv_copy, ciphertext, plaintext);
        mbedtls_aes_free(&aes);

        // PKCS#7 Padding entfernen
        uint8_t padding_len = plaintext[len - 1];
        if (padding_len < 1 || padding_len > 16) return "";

        size_t actual_len = len - padding_len;

        // String-Konvertierung mit Suche nach dem JSON-Start '{'
        // Verhindert, dass Header-Reste mitgeparst werden
        String result = "";
        bool foundStart = false;
        for (size_t i = 0; i < actual_len; i++) {
            if (!foundStart && plaintext[i] == '{') foundStart = true;
            if (foundStart) result += (char)plaintext[i];
        }

        return result;
    }
};
#endif
