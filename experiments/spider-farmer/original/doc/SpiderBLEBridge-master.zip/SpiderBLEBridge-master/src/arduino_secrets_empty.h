#ifndef SPIDERBLEBRIDGE_ARDUINO_SECRETS_EMPTY_H
#define SPIDERBLEBRIDGE_ARDUINO_SECRETS_EMPTY_H

// WLAN Daten
#define SECRET_SSID "apname"
#define SECRET_PASS "password"


#define SECRET_AES_KEY {0x42, 0x6B, 0x4A, 0x75, 0x36, 0x31, 0x6B, 0x4C, 0x74, 0x33, 0x61, 0x66, 0x75, 0x6F, 0x67} //, 0x54

#define SECRET_AES_IV  {0x32, 0x41, 0x4B, 0x56, 0x4E, 0x55, 0x62, 0x55, 0x34, 0x6D, 0x76, 0x55, 0x33, 0x45, 0x6C} //, 0x74

// Benutzer & Sensor Daten
#define SECRET_USER_ID "1000000"
#define SECRET_USER_EMAIL "example@example.com"
#define SECRET_MAC_ADDRESS "aa:bb:cc:dd:ee:ff"

// Timezone Einstellungen
#define SECRET_TIMEZONE "Europe/Berlin"
#define SECRET_TZ_STRING "CET-1CEST,M3.5.0,M10.5.0/3"

#endif //SPIDERBLEBRIDGE_ARDUINO_SECRETS_EMPTY_H