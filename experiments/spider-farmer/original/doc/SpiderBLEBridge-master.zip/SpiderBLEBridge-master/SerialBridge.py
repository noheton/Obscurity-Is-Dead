import serial
import time

# --- KONFIGURATION ---
SERIAL_PORT = 'COM9'
BAUD_RATE = 115200


def run_bridge():
    buffer = b""  # Puffer für unvollständige Daten

    try:
        # Verbindung öffnen ohne automatischen Reset
        ser = serial.Serial()
        ser.port = SERIAL_PORT
        ser.baudrate = BAUD_RATE
        ser.timeout = 0.1
        ser.dsrdtr = False
        ser.setRTS(False)
        ser.setDTR(False)
        ser.open()

        print(f"--- Monitoring auf {SERIAL_PORT} (Reset unterdrückt) ---")

        while True:
            # Alles lesen, was gerade im OS-Puffer liegt
            if ser.in_waiting > 0:
                chunk = ser.read(ser.in_waiting)
                buffer += chunk

                # Wenn ein Zeilenumbruch gefunden wurde, verarbeiten
                if b'\n' in buffer:
                    lines = buffer.split(b'\n')
                    # Die letzte (evtl. unvollständige) Zeile zurück in den Puffer
                    buffer = lines.pop()

                    for line in lines:
                        line = line.strip()
                        if not line:
                            continue

                        # Hex-Darstellung
                        hex_str = line.hex(' ').upper()

                        # Text-Versuch
                        try:
                            # Wir dekodieren mit 'ignore', um bei kleinen Fehlern nicht abzustürzen
                            text_msg = line.decode('utf-8', errors='ignore').strip()
                        except:
                            text_msg = "[Binär]"

                        # Anzeige
                        if "{" in text_msg and "}" in text_msg:
                            print(f"\033[92m[JSON] -> {text_msg}\033[0m")  # Grün für JSON
                        else:
                            print(f"Empfangen: {hex_str}")
                            print(f"  -> Text: {text_msg}")

            time.sleep(0.01)  # CPU entlasten

    except serial.SerialException as e:
        print(f"Fehler: {e}")
    except KeyboardInterrupt:
        print("\nBeendet.")
    finally:
        if 'ser' in locals() and ser.is_open:
            ser.close()


if __name__ == "__main__":
    run_bridge()